<section class="page-content section-block">
		<div class="container">
			<div class="row section-content">
				<div class="col-md-9">
					<div class="main-content">
						<div class="blog-posts">
							<article class="blogpost clearfix">
								<div class="image-block">
									<img class="img-responsive" src="img/about.jpeg" alt="article image">
								</div>
				
								<div class="post-content">
									<div class="content-wrapper">
										<h2 class="post-title"><a href="#">Duis aute irure dolor in repreh enderit in voluptate</a></h2>
										<ul class="post-meta">
											<li><i class="icon ion-person"></i><a href="#">Sanchit Singhal</a></li>
											<li><i class="icon ion-pricetag"></i><a href="#">Social Work</a></li>
											<li><i class="icon ion-chatbubbles"></i><a href="#">23 Comments</a></li>
										</ul>
										<p class="excerpt">
											Belaboris nisi ut aliquip ex ea commodo
											consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
											cillum dolore eu fugiat nulla pariat laborum.
										</p>
										<a class="read-more-link" href="#">KNOW MORE</a>
									</div> <!-- .content-wrapper ends -->
								</div> <!-- .post-content ends -->
							</article> <!-- .blogpost ends -->
							<article class="blogpost clearfix">
								<div class="image-block">
									<img class="img-responsive" src="img/about.jpeg" alt="article image">
								</div>
				
								<div class="post-content">
									<div class="content-wrapper">
										<h2 class="post-title"><a href="#">Nulla neque dolor sagittis eget iaculis quis molestie</a></h2>
										<ul class="post-meta">
											<li><i class="icon ion-person"></i><a href="#">Sanchit Singhal</a></li>
											<li><i class="icon ion-pricetag"></i><a href="#">Social Work</a></li>
											<li><i class="icon ion-chatbubbles"></i><a href="#">23 Comments</a></li>
										</ul>
										<p class="excerpt">
											Belaboris nisi ut aliquip ex ea commodo
											consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
											cillum dolore eu fugiat nulla pariat laborum.
										</p>
										<a class="read-more-link" href="#">KNOW MORE</a>
									</div> <!-- .content-wrapper ends -->
								</div> <!-- .post-content ends -->
							</article> <!-- .blogpost ends -->
						</div> <!-- .blog-posts ends -->
						
					</div> <!-- .main-content ends -->
				</div> <!-- .col-md-9 ends -->
				<div class="col-md-3">
					<div class="sidebar">
						<div class="widget recent-post">
							<div class="main-content">
								<div class="blog-posts">
									<article class="blogpost clearfix">
										<div class="image-block">
											<img class="img-responsive" src="img/about.jpeg" alt="article image">
										</div>
									</article> <!-- .blogpost ends -->
								</div>
							</div>
						</div> <!-- .widget ends -->
						<div class="widget recent-post" style="margin-top: -40px;">
							<div class="main-content">
								<div class="blog-posts">
									<article class="blogpost clearfix">
										<h3>HEADING SIDE</h3>
										<p style="font-size: 16px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
										tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
										quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
										consequat. </p>
									</article> <!-- .blogpost ends -->
								</div>
							</div>
						</div> <!-- .widget ends -->
					</div> <!-- .sidebar ends -->
				</div> <!-- .col-md-3 ends -->
			</div> <!-- .row ends -->
		</div> <!-- .container ends -->
	</section> <!-- .page-content ends -->