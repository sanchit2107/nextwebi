<section class="page-banner">
	<div class="container">
		<h2 class="page-title">Blog</h2>
		<ul class="breadcrumbs">
			<li><a href="#">Home</a></li>
			<li><a href="#">Blog</a></li>
		</ul> <!-- .breadcrumbs ends -->
	</div> <!-- .container ends -->
</section> <!-- .page-banner ends -->